package com.unbosque.wii.model;

import java.io.Serializable;

public class ObjectW implements Serializable{
	
	private String description,type,place,date,publisher;
	
	public ObjectW()
	{
		
	}

	public ObjectW(String description, String type, String place, String date, String publisher) 
	{
		this.description = description;
		this.type = type;
		this.place = place;
		this.date = date;
		this.publisher = publisher;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	

}
