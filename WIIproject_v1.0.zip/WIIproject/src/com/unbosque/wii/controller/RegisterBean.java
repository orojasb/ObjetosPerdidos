package com.unbosque.wii.controller;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.PrimeFaces;

@ManagedBean
@ViewScoped
public class RegisterBean implements Serializable{
	
	private String userName, userPass1, userPass2;
	
	public RegisterBean()
	{
		
	}
	
	public void register()
	{
		if(!userPass1.equals(userPass2))
		{
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Contraseña incorrecta", "Contraseñas no coinciden");
	         
	        PrimeFaces.current().dialog().showMessageDynamic(message);
		}
		else
		{
			//CODE DE REGISTRO
			System.out.println("User: "+userName);
			System.out.println("pass1: "+userPass1);
			System.out.println("pass2: "+userPass2);
		}
		
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass1() {
		return userPass1;
	}

	public void setUserPass1(String userPass1) {
		this.userPass1 = userPass1;
	}

	public String getUserPass2() {
		return userPass2;
	}

	public void setUserPass2(String userPass2) {
		this.userPass2 = userPass2;
	}

}
