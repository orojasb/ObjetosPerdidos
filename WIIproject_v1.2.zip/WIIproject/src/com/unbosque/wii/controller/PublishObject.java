package com.unbosque.wii.controller;

import java.io.Serializable;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class PublishObject implements Serializable {
	
	private String description,type,date;
	
	public PublishObject()
	{
		
	}
	
	public void finded()
	{
		this.date=getDateStr();
		System.out.println("Fecha: "+this.date);
		System.out.println("Descripcion: "+this.description);
		System.out.println("Tipo: "+this.type);
		
	}
	
	public void lost()
	{
		this.date=getDateStr();
		this.date=getDateStr();
		System.out.println("Fecha: "+this.date);
		System.out.println("Descripcion: "+this.description);
		System.out.println("Tipo: "+this.type);
		
	}
	
	public String getDateStr()
	{
		String date="";
		
		int year=new Date().getYear()+1900;
		int month=new Date().getMonth()+1;
		int day=new Date().getDate();
		
		date=String.valueOf(day)+"/"+String.valueOf(month)+"/"+String.valueOf(year);
		
		return date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
