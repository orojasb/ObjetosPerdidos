package com.unbosque.wii.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.unbosque.wii.model.ObjectW;

@ManagedBean
@ViewScoped
public class DeleteObjectBean {
	
	
	private List<ObjectW> objectsF,objectsL;
	
	public DeleteObjectBean()
	{
		
	}
	
	@PostConstruct
	public void init()
	{
		String type="Electrónico";
		String date="23/04/2018";
		
		objectsF=new ArrayList<>();
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsF.add(new ObjectW("description",type,"Place",date,"Publisher"));
		
		
		objectsL=new ArrayList<>();
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
		objectsL.add(new ObjectW("description",type,"Place",date,"Publisher"));
	}

	public List<ObjectW> getObjectsF() {
		return objectsF;
	}

	public void setObjectsF(List<ObjectW> objectsF) {
		this.objectsF = objectsF;
	}

	public List<ObjectW> getObjectsL() {
		return objectsL;
	}

	public void setObjectsL(List<ObjectW> objectsL) {
		this.objectsL = objectsL;
	}

}
