package com.unbosque.wii.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.unbosque.wii.model.ObjectW;

@ManagedBean
@ViewScoped
public class SearchObjectBean{
	
	private String description,type,place,date;
	
	private List<ObjectW> objectsF,objectsL;
	
	public SearchObjectBean()
	{
		
	}
	
	public void searchFinded()
	{
		System.out.println("Buscar encontrado por fecha: "+this.date);
		System.out.println("Buscar encontrado por tipo: "+this.type);
		
		//CREA DATA GRID
		objectsF=new ArrayList<>();
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsF.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
	}
	
	public void searchLost()
	{
		System.out.println("Buscar perdido por fecha: "+this.date);
		System.out.println("Buscar perdido por tipo: "+this.type);
		
		
		//CREA DATA GRID
		objectsL=new ArrayList<>();
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
		objectsL.add(new ObjectW("description",this.type,"Place",this.date,"Publisher"));
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public List<ObjectW> getObjectsF() {
		return objectsF;
	}

	public void setObjectsF(List<ObjectW> objectsF) {
		this.objectsF = objectsF;
	}

	public List<ObjectW> getObjectsL() {
		return objectsL;
	}

	public void setObjectsL(List<ObjectW> objectsL) {
		this.objectsL = objectsL;
	}

	public String getDateStr()
	{
		String date="";
		
		int year=new Date().getYear()+1900;
		int month=new Date().getMonth()+1;
		int day=new Date().getDate();
		
		date=String.valueOf(day)+"/"+String.valueOf(month)+"/"+String.valueOf(year);
		
		return date;
	}

}
