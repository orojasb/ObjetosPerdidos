package com.unbosque.wii.controller;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class LoginBean implements Serializable{
	
	private String userName,userPass;
	
	public LoginBean()
	{
		
	}
	
	public void login()
	{
		//CODE FOR LOGIN
		System.out.println("User: "+this.userName);
		System.out.println("Pass: "+this.userPass);
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String pass) {
		this.userPass = pass;
	}

}
